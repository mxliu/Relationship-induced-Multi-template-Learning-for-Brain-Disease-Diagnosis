clear, clc;

% This is an example for running the function mtLeastR
%  Problem:
%  min  1/2 sum_i || A_i x_i - y_i||^2 + z * sum_j ||x^j||_q 
%       + 1/2 *  lambda2 * sum_k ( sum_i ( sum_j ( ||w_k' * x_k^i - w_k' * x_k^j||_2^2 * S_ij^k ) ) )
%       + 1/2 *  lambda3 * sum_n ( sum_p ( sum_a ( ||w_p' * x_p^n - w_q' * x_q^n||_2^2 * S_pq^n ) ) )
%

addpath(genpath('SLEP'));
                     % add the functions in the folder SLEP to the path
m=1000;  n=80;     % the size of the data matrix
k=10;               % 10 tasks
ind=0:100:1000;     % the 1000 samples are from 10 tasks
randNum=1;          % a random number


% ---------------------- generate random data ----------------------
randn('state',(randNum-1)*3+1);
A=randn(m,n);        % the data matrix

randn('state',(randNum-1)*3+2);
xOrin=randn(n,k);

randn('state',(randNum-1)*3+3);
noise=randn(m,1);
data_num=(size(A,1)/k);

for i=1:k
    ind_i=(ind(i)+1):ind(i+1);
    y(ind_i,1)=A(ind_i,:)*xOrin(:,i)+...
        noise(ind_i,1)*0.01; % the response
end

for i=1:data_num
    for j=1:k
        B( (i-1)*k+j , : ) = A( (j-1)*data_num+i , : ); % Re-arrange the matrix A as matrix B
    end                     
end

% compute Lk within k-th atlas
S=zeros(data_num,data_num);
t=1;
for i=1:k
    Ai= A( (i-1)*data_num+1:(i-1)*data_num+data_num, :);
    yi= y( (i-1)*data_num+1:(i-1)*data_num+data_num, :);
    for m=1:data_num
        for n=1:data_num
             S(m,n)=exp( - norm( Ai(m,:)-Ai(n,:),2)^2 / t);
        end
    end
    Lk{i}=diag(sum(S'))-S;
end

% compute Ln within n-th subject
S=zeros(k,k);
for i=1:data_num
    Bi= B( (i-1)*k+1:(i-1)*k+k, :);
    yi= y( (i-1)*k+1:(i-1)*k+k, :);
    for m=1:k
        for n=1:k
            S(m,n)=exp( - norm( Bi(m,:)-Bi(n,:),2)^2 / t); % Can be replaced by 1
        end
    end
    Ln{i}=diag(sum(S'))-S;
end

aa=1;

%----------------------- Set optional items -----------------------
q=1;                % the value of q in the L1/Lq regularization
rho=0.5;            % the regularization parameter
opts=[];
% Starting point
opts.init=2;        % starting from a zero point
% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=50;   % maximum number of iterations
% Normalization
opts.nFlag=0;       % without normalization
% Regularization
opts.rFlag=1;       % the input parameter 'rho' is a ratio in (0, 1)
% Group Property
opts.q=q;           % set the value for q
opts.ind=ind;       % set the group indices

%----------------------- Run the code mtLeastR -----------------------
fprintf('\n mFlag=0, lFlag=0 q=1 \n');
opts.mFlag=0;       % treating it as compositive function 
opts.lFlag=0;       % Nemirovski's line search
opts.lambda2=0.1;
opts.lambda3=0.1;
tic;
tic
[x1, funVal1, ValueL1]= viewAlign_mtLeastR(A, y, B, Lk, Ln, rho, opts);
toc;

figure;
plot(funVal1,'-r');
hold on
legend('mFlag=0, lFlag=0 q=1');
xlabel('Iteration #');
ylabel('The objective function value');

aa=1;
